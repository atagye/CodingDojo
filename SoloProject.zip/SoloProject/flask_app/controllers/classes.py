from flask import render_template, session, flash, request, redirect
from flask_app import app
from flask_app.models.user import User
from flask_app.models.class import Class

@app.route('/classes/new')
def add_class():
    if 'user_id' not in session:
        return redirect('/')
    data = {
        'id': session['user_id']
    }
    return render_template('addclass.html', user = User.get_by_id(data))

@app.route('/my_creations')
def my_creations():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        'id': session['user_id']
    }
    return render_template("my_creations.html", user = User.get_by_id(data), all_classs = Class.get_all_classes_with_users())

@app.route('/classes/<int:id>')
def view_class_page(id):
    if 'user_id' not in session:
        return redirect('/')

    data = {
        'id': id
    }
    return render_template('view_one_class.html', this_class = Class.get_one_class_with_user(data))

@app.route('/classes/<int:id>/delete')
def delete_class(id):
    if 'user_id' not in session:
        return redirect('/')
    data = {
        'id': id
    }
    Class.delete_class(data)
    return redirect('/my_creations')

@app.route('/classes/<int:id>/edit')
def edit_class_page(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        'id': id
    }
    return render_template('edit_class_page.html', this_class = Class.get_one_class_with_user(data))

@app.route('/classes/<int:id>/edit_in_db', methods = ["POST"])
def edit_class_in_db(id):
    if 'user_id' not in session:
        return redirect('/')
    if not Class.validate_class(request.form):
        return redirect(f'/classes/{id}/edit')
    data = {
        "name": request.form['name'],
        "asi": request.form['asi'],
        "skills": request.form['skills'],
        "description": request.form['description'],
        "id": id
    }
    Class.edit_class(data)
    return redirect(f'/classes/{id}')

@app.route('/classes/add_to_db', methods = ["POST"])
def add_class_to_db():
    if 'user_id' not in session:
        return redirect('/')
    if not Class.validate_class(request.form):
        return redirect('/classes/new')
    data = {
        "name": request.form['name'],
        "asi": request.form['asi'],
        "skills": request.form['skills'],
        "description": request.form['description'],
        "user_id": session['user_id']
    }
    Class.add_class(data)
    return redirect('/my_creations')