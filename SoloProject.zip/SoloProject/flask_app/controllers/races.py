from flask import render_template, redirect, request
from flask_app import app
from flask_app.models.race import Race

@app.route('/create/race', methods=['POST'])
def create_race():
    Race.save(request.form)
    return redirect('/races')