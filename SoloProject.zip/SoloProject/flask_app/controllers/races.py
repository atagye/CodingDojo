from flask import render_template, session, flash, request, redirect
from flask_app import app
from flask_app.models.user import User
from flask_app.models.race import Race

@app.route('/races/new')
def add_race():
    if 'user_id' not in session:
        return redirect('/')
    data = {
        'id': session['user_id']
    }
    return render_template('addrace.html', user = User.get_by_id(data))

@app.route('/my_creations')
def my_creations():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        'id': session['user_id']
    }
    return render_template("my_creations.html", user = User.get_by_id(data), all_races = Race.get_all_races_with_users())

@app.route('/races/<int:id>')
def view_race_page(id):
    if 'user_id' not in session:
        return redirect('/')

    data = {
        'id': id
    }
    return render_template('view_one_race.html', this_race = Race.get_one_race_with_user(data))

@app.route('/races/<int:id>/delete')
def delete_race(id):
    if 'user_id' not in session:
        return redirect('/')
    data = {
        'id': id
    }
    Race.delete_race(data)
    return redirect('/my_creations')

@app.route('/races/<int:id>/edit')
def edit_race_page(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        'id': id
    }
    return render_template('edit_race_page.html', this_race = Race.get_one_race_with_user(data))

@app.route('/races/<int:id>/edit_in_db', methods = ["POST"])
def edit_race_in_db(id):
    if 'user_id' not in session:
        return redirect('/')
    if not Race.validate_race(request.form):
        return redirect(f'/races/{id}/edit')
    data = {
        "name": request.form['name'],
        "asi": request.form['asi'],
        "skills": request.form['skills'],
        "description": request.form['description'],
        "id": id
    }
    Race.edit_race(data)
    return redirect(f'/races/{id}')

@app.route('/races/add_to_db', methods = ["POST"])
def add_race_to_db():
    if 'user_id' not in session:
        return redirect('/')
    if not Race.validate_race(request.form):
        return redirect('/races/new')
    data = {
        "name": request.form['name'],
        "asi": request.form['asi'],
        "skills": request.form['skills'],
        "description": request.form['description'],
        "user_id": session['user_id']
    }
    Race.add_race(data)
    return redirect('/my_creations')