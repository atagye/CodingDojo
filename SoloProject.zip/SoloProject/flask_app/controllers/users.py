from flask import render_template, session, flash, request, redirect
from flask_app import app
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)
import re
from flask_app.models.user import User
from flask_app.models.race import Race

@app.route('/')
def homepage():
    return render_template('homepage.html')

@app.route('/races')
def races():
    return render_template('races.html')

@app.route('/yqlahn')
def yqlahn():
    return render_template('yqlahn.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST' and 'name' in request.form and 'email' in request.form and 'password' in request.form:
        data = {
            "name": request.form['name'],
            "email": request.form['email'],
            "password": bcrypt.generate_password_hash(request.form['password'])
            }
        id = User.save(data)
        session['user_id'] = id
        return redirect('/welcome')

@app.route('/login', methods=['POST'])
def login():
    user = User.get_by_email(request.form)
    if not user:
        flash("Invalid Email and/or Password", "login")
        return redirect('/')
    if not bcrypt.check_password_hash(user.password, request.form['password']):
        flash("Invalid Email and/or Password", "login")
        return redirect('/')
    session['user_id'] = user.id
    return redirect('/welcome')

@app.route('/welcome')
def welcome():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        'id': session['user_id']
    }
    return render_template("welcome.html", user = User.get_by_id(data))

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')