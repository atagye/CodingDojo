from flask_app.config.mysqlconnection import MySQLConnection, connectToMySQL
from flask import flash
from flask_app.models.user import User
import re

class Class:
    db = "solo-homebrew-schema"
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.asi = data['asi']
        self.skills = data['skills']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user = None

    @classmethod
    def add_class(cls, data):
        query = 'INSERT INTO classes (name, asi, skills, description, user_id) VALUES (%(name)s, %(asi)s, %(skills)s, %(description)s, %(user_id)s);'
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def delete_class(cls, data):
        query = 'DELETE FROM classes WHERE id = %(id)s;'
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def edit_class(cls, data):
        query = "UPDATE classes SET name = %(name)s, asi = %(asi)s, skills = %(skills)s, description = %(description)s WHERE id = %(id)s;"
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def get_all_classes_with_users(cls):
        query = 'SELECT * FROM classes JOIN users ON classes.user_id = users.id;'
        results = connectToMySQL(cls.db).query_db(query)
        if len(results) == 0:
            return []
        else:
            all_classes = []
            for this_class_dictionary in results:
                this_class_object = cls(this_class_dictionary)
                this_user_dictionary = {
                    'id': this_class_dictionary['users.id'],
                    'name': this_class_dictionary['name'],
                    'email': this_class_dictionary['email'],
                    'password': this_class_dictionary['password'],
                    'created_at': this_class_dictionary['users.created_at'],
                    'updated_at': this_class_dictionary['users.updated_at']
                }
                this_user_object = User(this_user_dictionary)
                this_class_object.user = this_user_object
                all_classes.append(this_class_object)
            return all_classes

    @classmethod
    def get_classes_by_this_user(cls, data):
        query = 'SELECT * FROM users LEFT JOIN classes ON users.id = classes.user_id WHERE users.id = %(id)s;'
        results = connectToMySQL(cls.db).query_db(query, data)
        print(results)
        if len(results) == 0:
            return None
        else:
            this_user = User(results[0])

            if results[0]['classes.id'] != None:

                for this_class_dictionary in results:

                    new_class_directory = {
                        'id': this_class_dictionary['classes.id'],
                        'name': this_class_dictionary['name'],
                        'asi': this_class_dictionary['asi'],
                        'skills': this_class_dictionary['skills'],
                        'description': this_class_dictionary['description'],
                        'created_at': this_class_dictionary['classes.created_at'],
                        'updated_at': this_class_dictionary['classes.updated_at']
                    }
                    this_class_object = cls(new_class_directory)
                    this_user.classes.append(this_class_object)
            return this_user

    @classmethod
    def get_one_class_with_user(cls, data):
        query = 'SELECT * FROM classes JOIN users ON users.id = classes.user_id WHERE classes.id = %(id)s;'
        results = connectToMySQL(cls.db).query_db(query, data)
        if len(results) == 0:
            return None
        else:
            this_class_object = cls(results[0])
            this_user_dictionary = {
                'id': results[0]['users.id'],
                'name': results[0]['name'],
                'email': results[0]['email'],
                'password': results[0]['password'],
                'created_at': results[0]['users.created_at'],
                'updated_at': results[0]['users.updated_at']
            }
            this_user_object = User(this_user_dictionary)
            this_class_object.user = this_user_object
            return this_class_object


    @staticmethod
    def validate_class(form_data):
        is_valid = True
        if len(form_data['name']) < 2:
            is_valid = False
            flash("Name must be 2 or more characters.", "login")
        if len(form_data['asi']) < 4:
            is_valid = False
            flash("Ability Score Increase must be 4 or more characters.", "login")
        if len(form_data['skills']) < 4:
            is_valid = False
            flash("Skills must be 4 or more characters. If None, put None.", "login")
        if len(form_data['description']) < 10:
            is_valid = False
            flash("Description must be 10 or more characters.", "login")
        return is_valid
