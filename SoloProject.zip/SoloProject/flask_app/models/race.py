from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re

class Race:
    db = "solo-hombrew-schema"
    def __init__(self,data):
        self.id = data['id']
        self.name = data['name']
        self.asi = data['asi']
        self.skills = data['skills']
        self.desc = data['desc']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM races;"
        results = connectToMySQL('solo-homebrew-schema').query_db(query)
        races = []
        for row in results:
            races.append(cls(row))
        return races

    @classmethod
    def save(cls,data):
        query = "INSERT INTO races (name, asi, skills, desc) VALUES (%(name)s, %(asi)s, %(skills)s, %(desc)s);"
        return connectToMySQL(User.db).query_db(query, data)